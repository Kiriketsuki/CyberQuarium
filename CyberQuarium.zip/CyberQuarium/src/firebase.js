// Import the functions you need from the SDKs you need

import { initializeApp } from "firebase/app";

// Your web app's Firebase configuration

const firebaseConfig = {

  apiKey: "AIzaSyBhsdJ9YKqTC8spS7ssM9JJuepQPfG6tnU",

  authDomain: "cyberquarium-298eb.firebaseapp.com",

  projectId: "cyberquarium-298eb",

  storageBucket: "cyberquarium-298eb.appspot.com",

  messagingSenderId: "952929382050",

  appId: "1:952929382050:web:edda2e058cd62ec27eb1fb"

};


// Initialize Firebase

const app = initializeApp(firebaseConfig);

export default app;