// store.js
import { writable } from 'svelte/store';

export const data_store = writable({
    user: "",
});