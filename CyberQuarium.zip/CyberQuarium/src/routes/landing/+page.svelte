<body class="w-screen h-screen bg-background flex flex-col justify-center items-center">

    <div class="w-[80vw] flex flex-col items-center gap-[5rem]">
        <h1 class="font-title text-text text-9xl">
            CyberQuarium
        </h1>
    
        <div class="w-full flex flex-row justify-center">
            <div class="w-1/2 text-center">
                <a href="/login">
                    Login
                </a>
            </div>
    
            <div class="w-1/2 text-center">
                <a href="/register">
                    Register
                </a>
            </div>
        </div>
    </div>
</body>
